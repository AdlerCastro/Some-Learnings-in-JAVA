package questao.pkg2;

class Leitor {
    String Nome;
    
    public Leitor(String nome){
        this.Nome= nome;
    }
}
