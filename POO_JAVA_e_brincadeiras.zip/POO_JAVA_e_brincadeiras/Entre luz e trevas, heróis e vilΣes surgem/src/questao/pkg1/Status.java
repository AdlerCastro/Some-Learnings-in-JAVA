package questao.pkg1;

public interface Status {
    //Métodos a serem implementados nas classes selecionadas
    public void escreverStatus();
}
