package questao.pkg2;

public class Questao2 {

    public static void main(String[] args) {
        
    }
    
}
