## Hi👋(•ω•`)o, this repository is intended for some knowledge in JAVA acquired in the second semester of Computer Engineering

In this repository you will find topics such as:
- Arrays e ArrayList
- POO (Object Oriented Programming) JAVA
- Classes
- Encapsulation
- Inheritance 
- Polymorphism
- Abstract class
- Extends and Implements
- Interface
- Programming logic

Enjoy and have great studies ✍️(◔◡◔)