package questao.pkg2;

import java.util.ArrayList;

class Livro {
    private String titulo;
    private String autor;
    ArrayList<Leitor> leitores;
}
